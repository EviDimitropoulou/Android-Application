package com.example.evi.mobtest.Model;

/**
 * Created by evi on 1/16/2017.
 */

public class Rain {
}
