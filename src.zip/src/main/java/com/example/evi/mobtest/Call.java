package com.example.evi.mobtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Call extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
    }
}
