package com.example.evi.mobtest.Model;

/**
 * Created by evi on 1/16/2017.
 */

public class Clouds {
    private int all;

    public Clouds(int all) {
        this.all = all;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}

