<?php
$servername = "localhost";
$username1 = "root";
$password1 = "";
$db_name="mobtect";
// Create connection
$conn = mysqli_connect($servername, $username1, $password1,$db_name);
// Check connection
$username=$_POST["username"];
$email= $_POST["email"];
$password=  $_POST["password"];
$town=$_POST["town"];
$birthdate= $_POST["birthdate"];
$category= $_POST["category"];

	$options = ['cost' => 12,];
$hash = password_hash("$password", PASSWORD_BCRYPT, $options);
//insert into database
mysqli_select_db($conn,"mobtect");
$query = "INSERT INTO `registration` (`username`, `email`,`town` ,`password`,`birthdate`, `category`) VALUES ('$username', '$email','$town','$hash', '$birthdate', '$category')";
mysqli_query($conn, $query) or die (mysqli_error($conn));
    
$response=array();
$response["success"]=true;
echo json_encode($response);
?>