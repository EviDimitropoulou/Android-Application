<?php
$servername = "localhost";
$username1 = "root";
$password1 = "";
$db_name="mobtect";
// Create connection
$conn = mysqli_connect($servername, $username1, $password1,$db_name);
// Check connection
$username=$_POST["username"];
$email=$_POST["email"];
$password=  $_POST["password"];


	//$options = ['cost' => 12,];
//hash = password_hash("$password", PASSWORD_BCRYPT, $options);
//insert into database
mysqli_select_db($conn,"mobtect");
$query ="UPDATE  `registration` SET `username`='$username',`email`='$email', `password`='$password' WHERE `email`='$email' ";
//$query = "UPDATE table `registation` (`name`, `surname`, `password`) VALUES (, , ";
mysqli_query($conn, $query) or die (mysqli_error($conn));
    
$response=array();
$response["success"]=true;
echo json_encode($response);
?>