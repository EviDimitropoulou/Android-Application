	<?php
	$servername = "localhost";
	$username1 = "root";
	$password1 = "";
	$db_name="mobtect";
	$conn = mysqli_connect($servername, $username1, $password1,$db_name);


	$email= $_POST["email"];
	$password=$_POST["password"];
	//$username=$_POST["username"];
 $hash = "SELECT `password` from registration where email='$email' ";
    $result_hash = mysqli_query($conn, $hash) or die(myslqi_error($conn));
if (mysqli_num_rows($result_hash) >= 0) {
        while ($row = mysqli_fetch_assoc($result_hash)) {
            $pas_res = password_verify($password, $row["password"]);
        }
    }
	$statement = mysqli_prepare($conn, "SELECT * FROM registration WHERE email = ? ");
		mysqli_stmt_bind_param($statement, "s", $email);
		mysqli_stmt_execute($statement);


	$response = array();
		$response["success"] = false;  
		
		while(mysqli_stmt_fetch($statement)){
			$response["success"] = true;  
			//$response ["username"]=$username;
			$response ["email"]=$email;
			//$response ["town"]=$town;
			$response ["password"]=$password;
			//$response ["birthdate"]=$birthdate;
			// $response ["category"]=$category;
		}
		
		echo json_encode($response);
	?>